<template>
  <router-view :key="router.path"></router-view>
</template>

<script setup>
import router from "@/router"

</script>

<style scoped>

</style>