<template>
  <div class="test">
    <el-container>
      <el-main>
        <el-card>
          <template #header> 测试页面 </template>
          <p>测试页面</p>
        </el-card>
      </el-main>
    </el-container>
  </div>
</template>
<script lang="ts" setup></script>
<style lang="scss">
// 关于页面样式
.test {
  width: 100%;
  height: 100%;
  margin: 0;
  padding: 0;
}
</style>
