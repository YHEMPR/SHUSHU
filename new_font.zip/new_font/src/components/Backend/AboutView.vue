<template>
  <div class="about">
    <el-container>
      <el-main>
        <el-card>
          <template #header> 开源信息 </template>
          <p>作者信息：KSaMar</p>
          <p>该项目模拟学校图书馆的图书管理系统</p>
          <p>
            码云下载地址：<a
              href="https://github.com/baobaoJK/Vue-Element-Plus-SpringBoot-Library"
              >Gitee</a
            >
          </p>
          <p>
            GitHub下载地址：<a
              href="https://gitee.com/baobao_JK/Vue-Element-Plus-SpringBoot-Library"
              >GitHub</a
            >
          </p>
          <p>文档地址：<a href="#">文档.md</a></p>
        </el-card>
      </el-main>
    </el-container>
  </div>
</template>

<script lang="ts" setup></script>

<style lang="scss">
@import "@/assets/css/about";
</style>
